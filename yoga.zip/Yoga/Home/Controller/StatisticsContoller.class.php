<?php
namespace Home\Controller;
 use Think\Controller;
 /**
  * statistics script
  */
class StatisticsController extends Controller {
	 
}