<?php
namespace Pt\Controller;
use Common\Controller\BaseController;
class ReportController extends BaseController {
	public function indexAction()
	{
		$this->display();
	}

	public function queryAction()
	{
		
	}
}