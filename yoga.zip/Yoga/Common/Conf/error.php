<?php
return array( 
    'password_error' => "原始密码错误！",
    'confirm_password_error'=>'确认密码错误！',
    'new_password_error'=>'密码名6-30位数字或字母！',
    'bill_project_valid'=>"This Bill Project Is Not Exist!",
    'bill_project_paid_all'=>"此项目账单已结清，无须再付款！",
    'bill_project_paid_back'=>"此项目账单已退款，无须再付款！",
    'pay_too_much'=>"付款金额超出需付款金额，请重新收款！",
);