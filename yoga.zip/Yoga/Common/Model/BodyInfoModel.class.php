<?php
namespace Common\Model;
use Think\Model;
class BodyInfoModel extends Model {
}