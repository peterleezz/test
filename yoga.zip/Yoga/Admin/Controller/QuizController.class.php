<?php
namespace Admin\Controller;
use Think\Controller; 
class QuizController extends AdminController {
	public function indexAction()
	{
		$this->display();
	}
}
